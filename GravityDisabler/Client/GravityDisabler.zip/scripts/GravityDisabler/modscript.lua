setExtensionUnloadMode("GravityDisabler", "manual")
