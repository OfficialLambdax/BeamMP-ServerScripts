

local M = {}

local CORE_ENVIRONMENT_SET_STATE
--local CORE_ENVIRONMENT_REQUEST_STATE

-- ----------------------------------------------------------------------------
-- Load/Unload
local function init()
	CORE_ENVIRONMENT_SET_STATE = core_environment.setState
	core_environment.setState = function(data)
		if data.gravity ~= nil then
			data.gravity = nil
			--log('w', 'GravityDisabler', 'Gravity setter was blocked')
		end
		CORE_ENVIRONMENT_SET_STATE(data)
	end

	--[[
	CORE_ENVIRONMENT_REQUEST_STATE = core_environment.requestState
	CORE_ENVIRONMENT_REQUEST_STATE = function()
		local state = core_environment.getState()
		state.gravity = nil
		guihooks.trigger("EnvironmentStateUpdate", state)
		guihooks.trigger("EnvironmentCanUpdateChanged", core_environment.canChange())
	end
	]]

	log('I', 'GravityDisabler', 'Gravity can no longer be manipulated via the environment tab')
end

local function unload()
	core_environment.setState = CORE_ENVIRONMENT_SET_STATE or core_environment.setState
	--core_environment.requestState = CORE_ENVIRONMENT_REQUEST_STATE or core_environment.requestState
end

-- ----------------------------------------------------------------------------
-- Game Events
M.onWorldReadyState = function(state)
    if state == 2 then init() end
end

M.onExtensionLoaded = function()
    if worldReadyState == 2 then init() end
end

M.onExtensionUnloaded = unload

M.onClientEndMission = unload

M.onModDeactivated = function(mod_data)
	if mod_data.modname == "gravitydisabler" then extensions.unload("GravityDisabler") end
end


return M
