-- Made by Neverless @ BeamMP. Issues? Feel free to ask.
local VERSION = "0.2" -- 18.08.2024 (DD.MM.YYYY)

local M = {}
M.routineTimer = hptimer()
M.globalSyncTime = 5000
M.enabled = false
M.setToState = {
	play = false,
	dayScale = 0,
	nightScale = 0,
	time = 0,
	gravity = -9.8100004196167,
	startTime = 0,
	temperatureC = 0,
	fogDensity = 0,
	azimuthOverride = 0,
	windSpeed = 0,
	cloudCover = 0
}

M.setStatePointer = core_environment.setState
M.requestStatePointer = core_environment.requestState

---------------------------------------------------------------------------------------------
-- Basics
M.tableSize = function(table)
	if type(table) ~= "table" then return 0 end
	local len = 0
	for k, v in pairs(table) do
		len = len + 1
	end
	return len
end

M.inRange = function(value, min, max)
	return value >= min and value <= max
end

M.stateDiff = function()
	local diff = {}
	local state = core_environment.getState()
	state.play = state.play or false
	for k, v in pairs(state) do
		if type(v) == "number" and type(M.setToState[k]) == "number" then
			if k == "time" then
				if not M.inRange(v, M.setToState[k] - 0.001, M.setToState[k] + 0.001) then
					diff[k] = v
				end
			else
				if not M.inRange(v, M.setToState[k] - 0.01, M.setToState[k] + 0.01) then
					diff[k] = v
				end
			end
		else
			if v ~= M.setToState[k] then
				diff[k] = v
			end
		end
	end
	
	-- unsupported, server ignores them. unnecessary data traffic
	diff.startTime = nil
	diff.temperatureC = nil
	diff.azimuthOverride = nil
	
	return diff
end

---------------------------------------------------------------------------------------------
-- Game patches
M.patch = function()
	core_environment.setState = function() end
	core_environment.requestState = function()
		local state = core_environment.getState()
		guihooks.trigger("EnvironmentStateUpdate", {time = state.time, play = state.play})
	end
end

M.unpatch = function()
	core_environment.setState = M.setStatePointer
	core_environment.requestState = M.requestStatePointer
end

---------------------------------------------------------------------------------------------
-- Routines
M.coreRoutine = function(dt)
	--if M.enabled == false then return nil end -- needs to run for `/esync updateenv` to work
	if M.routineTimer:stop() > M.globalSyncTime then
		M.routineTimer:stopAndReset()
		local diff = M.stateDiff()
		if M.tableSize(diff) > 0 then TriggerServerEvent("envsync_updateenv", jsonEncode(diff)) end
	end
end

---------------------------------------------------------------------------------------------
-- MP Events
M.updateEnv = function(raw_msg)
	if raw_msg:len() > 0 then
		if not M.enabled then
			M.enabled = true
			M.patch()
		end
		local state = jsonDecode(raw_msg)
		for k, v in pairs(state) do -- add it instead of overwrite as the given state is dynamic
			M.setToState[k] = v
		end
		M.setStatePointer(M.setToState)
		TriggerServerEvent("envsync_updateenv", raw_msg)
		
		
	else -- empty means disable
		if M.enabled then
			M.enabled = false
			M.unpatch()
		end
	end
end

M.updateSyncTime = function(raw_msg)
	M.globalSyncTime = tonumber(raw_msg)
end

---------------------------------------------------------------------------------------------
-- Game Events
M.onWorldReadyState = function(state)
	if state == 2 then
		if AddEventHandler then -- if beammp is present
			M.onExtensionUnloaded = M.unpatch
			M.onUpdate = M.coreRoutine
			
			AddEventHandler("envsync_updateenv", M.updateEnv)
			AddEventHandler("envsync_updatesynctime", M.updateSyncTime)
			
		end
	end
end

return M
