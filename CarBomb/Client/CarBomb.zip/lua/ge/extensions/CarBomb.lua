--[[
	Todo
		- Make it possible to only activate the bomb once
]]
local M = {}
--[[
	States
		0 = Disabled
		1 = Before vehicle reaches X kph
		2 = Vehicle is above X kph, check for below.
			If so show warning and tick down time. otherwise go to 3
		3 = Vehicle Boom
		4 = Wait for reset. After reset go to 1
]]
M.State = 0
M.SpeedKph = 40
M.WarnMaxTime = 3000 -- ms
M.WarnTimer = nil -- nil/hptimer
M.WarnSoundTimer = hptimer()
M.StartTimer = nil -- nil/hptimer

-----------------------------------------------------------------------------------------------
-- Basics
local function getMyVehicles()
	local vehicles = {}
	for i = be:getObjectCount()-1, 0, -1 do
		local veh = be:getObject(i)
		if veh.isTraffic == "false" or veh.isTraffic == nil then -- ignore traffic vehicles -- also check if vehicle is unicycle <<=====<<<< todo
			local gameVehicleID = veh:getID()
				
			-- if mp is loaded, check that vehicle is owned by us
			if (MPVehicleGE == nil or MPVehicleGE.isOwn == nil) or (MPCoreNetwork.isMPSession() == false or MPVehicleGE.isOwn(gameVehicleID)) then
				table.insert(vehicles, {gameVehicleID = gameVehicleID, veh = veh})
			end
		end
	end
	
	return vehicles
end

local function playSound(sound_name, volume)
	Engine.Audio.playOnce('AudioGui', "/art/sound/" .. sound_name, {volume = volume or 25})
end

-----------------------------------------------------------------------------------------------
-- Toaster
local TOASTR = {}
function TOASTR:info(title, text, length)
	guihooks.trigger('toastrMsg', {type="info", title = title or "", msg = text or "", config = {timeOut = length or 5000}})
end

function TOASTR:warn(title, text, length)
	guihooks.trigger('toastrMsg', {type="warning", title = title or "", msg = text or "", config = {timeOut = length or 5000}})
end

function TOASTR:error(title, text, length)
	guihooks.trigger('toastrMsg', {type="error", title = title or "", msg = text or "", config = {timeOut = length or 5000}})
end

-----------------------------------------------------------------------------------------------
-- Multiplayer related
-- returns the vehicle id as Y not X-Y
local function gameVehicleID2ServerVehicleString(gameVehicleID)
	if MPVehicleGE == nil then return nil end
	for serverVehicleID, vehicle in pairs(MPVehicleGE.getVehicles()) do
		if vehicle.gameVehicleID == gameVehicleID then
			return tonumber(serverVehicleID:sub(serverVehicleID:find("-") + 1, -1))
		end
	end
end

local function sendExplosionToServer(gameVehicleID)
	local serverVehicleString = gameVehicleID2ServerVehicleString(gameVehicleID)
	if serverVehicleString == nil then return nil end
	
	TriggerServerEvent("carbomb_exploded", tostring(serverVehicleString))
end

-----------------------------------------------------------------------------------------------
-- Routines
local function onUpdate()
	if M.State == 0 then
		-- nonanothing
		
	elseif M.State == 1 then
		local vehicles = getMyVehicles()
		for _, vehicle in pairs(vehicles) do
			local vel = vehicle.veh:getVelocity()
			local vel_kph = math.floor(math.sqrt(vel.x^2 + vel.y^2 + vel.z^2) * 3.6)
			
			if vel_kph > M.SpeedKph then
				if M.StartTimer == nil then M.StartTimer = hptimer() end
				
				if M.StartTimer:stop() > 1000 then
					M.StartTimer = nil
					TOASTR:warn("CarBomb Activated")
					playSound("bomb_has_been_planted", 50)
					M.State = 2
				end
			else
				M.StartTimer = nil
			end
		end
		
	elseif M.State == 2 then
		local vehicles = getMyVehicles()
		if #vehicles == 0 then M.State = 1 end
		for _, vehicle in pairs(vehicles) do
			local vel = vehicle.veh:getVelocity()
			local vel_kph = math.floor(math.sqrt(vel.x^2 + vel.y^2 + vel.z^2) * 3.6)
			
			if vel_kph < M.SpeedKph then
				-- play sound
				if M.WarnSoundTimer:stop() > 1000 then
					playSound("warn_below_2", 30)
					M.WarnSoundTimer:stopAndReset()
				end
				
				if M.WarnTimer == nil then M.WarnTimer = hptimer() end
				if M.WarnTimer:stop() > M.WarnMaxTime then
					M.WarnTimer = nil
					M.State = 3
				end
			else
				M.WarnTimer = nil
			end
		end
		
	elseif M.State == 3 then
		-- play sound
		playSound("explosion_2", 30)
		local vehicles = getMyVehicles()
		for _, vehicle in pairs(vehicles) do
			vehicle.veh:queueLuaCommand("if CarBomb then CarBomb.onExplode() end")
			sendExplosionToServer(vehicle.gameVehicleID)
		end
		M.State = 4
		
	elseif M.State == 4 then
		-- nonanothing
	end
end

-----------------------------------------------------------------------------------------------
-- MP Events
local function enableBomb()
	M.State = 1
end

local function disableBomb()
	if M.State == 0 then return nil end
	TOASTR:info("CarBomb Disabled")
	M.State = 0
end

local function setSpeed(speed)
	M.SpeedKph = tonumber(speed)
end

local function explode(serverVehicleID)
	local veh = MPVehicleGE.getVehicles()[serverVehicleID]
	if veh == nil then return nil end
	local veh = be:getObjectByID(veh.gameVehicleID)
	if veh == nil then return nil end
	
	veh:queueLuaCommand("if CarBomb then CarBomb.onExplode() end")
end

-----------------------------------------------------------------------------------------------
-- NG Events
-- adding events later.. 0.31 mod loading makes it tho that functions of other mods
-- are sometimes not available during this mods loading.
local function onWorldReadyState(state)
	if state == 2 then
		-- only load if BeamMP is present
		if AddEventHandler then
			AddEventHandler("carbomb_enable", enableBomb)
			AddEventHandler("carbomb_disable", disableBomb)
			AddEventHandler("carbomb_setspeed", setSpeed)
			AddEventHandler("carbomb_explode", explode)
			if MPCoreNetwork.isMPSession() then
				M.State = 0
			else
				M.State = 1
			end
		else
			M.State = 1
		end
	end
end

local function onVehicleResetted(gameVehicleID)
	local vehicles = getMyVehicles()
	local found = false
	for _, vehicle in pairs(vehicles) do
		if vehicle.gameVehicleID == gameVehicleID then
			found = true
		end
	end
	if found == false then return nil end
	if M.State > 1 and M.State < 4 then
		M.State = 3
	elseif M.State == 4 then
		M.State = 1
	end
end


M.getMyVehicles = getMyVehicles
M.onWorldReadyState = onWorldReadyState
M.onVehicleResetted = onVehicleResetted
M.onUpdate = onUpdate
return M
