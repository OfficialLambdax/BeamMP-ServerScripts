local M = {}

function onExplode()
    fire.explodeVehicle()
    fire.igniteVehicle()
    beamstate.breakAllBreakgroups()
end

M.onExplode = onExplode
return M
