local M = {}
local BASE64 = require("base64")

function showNotice(msg)

	local msg = BASE64.decode(msg)
	local msg = jsonDecode(msg)
	
	local data = {}
	data.showDataImmediately = true
	data.introType = "htmlOnly"
	data.name = msg.name
	data.buttonText = msg.buttonText
	data.description = msg.description -- https://www.systutorials.com/tools/bbeditor/
	guihooks.trigger('ChangeState', {state = 'scenario-start', params = {data = data}})
end

-- only load if BeamMP is present
if AddEventHandler then
	AddEventHandler("autokick_warning", showNotice)
end

return M
