local M = {}

local function gameVehicleIDToServerVehicleID(game_vehicle_id)
	local server_vehicle_id = MPVehicleGE.getServerVehicleID(game_vehicle_id)
	if not server_vehicle_id or server_vehicle_id == -1 then return end
	return server_vehicle_id
end

local function serverVehicleIDToGameVehicleID(server_vehicle_id)
	local game_vehicle_id = MPVehicleGE.getGameVehicleID(server_vehicle_id)
	if not game_vehicle_id or game_vehicle_id == -1 then return end
	return game_vehicle_id
end

local function rotateVectorByDegrees(for_vec, up_vec, degrees)
	local a = for_vec
	local b = up_vec
	local q = degrees
	local c = a:cross(b)
	
	local term1 = a * math.cos(q)
	return vec3(
		term1.x + (c.x * math.sin(q)),
		term1.y + (c.y * math.sin(q)),
		term1.z + (c.z * math.sin(q))
	)
end

local function alignToSurfaceZ(pos_vec, max)
	local pos_z = be:getSurfaceHeightBelow(vec3(pos_vec.x, pos_vec.y, pos_vec.z + 2))
	if pos_z < -1e10 then return end -- "the function returns -1e20 when the raycast fails"
	if max and math.abs(pos_vec.z - pos_z) > max then return end
	
	return vec3(pos_vec.x, pos_vec.y, pos_z)
end

local function createCircle(vehicle)
	local c_pos = vehicle:getSpawnWorldOOBB():getCenter()
	local f_dir = vehicle:getDirectionVector():normalized()
	local u_dir = vehicle:getDirectionVectorUp():normalized()
	
	local distances = {8, 16, 24}
	local circle = {
		c_pos = c_pos,
		c_up = u_dir
	}
	for _, dist in ipairs(distances) do
		for rot = 1, 8, 1 do
			local r_pos = c_pos + (rotateVectorByDegrees(f_dir, u_dir, 0.785 * rot) * dist)
			table.insert(
				circle,
				alignToSurfaceZ(
					r_pos
				) or r_pos
			)
		end
	end
	
	return circle
end

local function tpToPos(circle, id, vehicle)
	local pos = circle[id]
	if not pos then return end
	
	local dir = (pos - circle.c_pos):normalized()
	local rot = quatFromDir(-dir, circle.u_dir)
	
	vehicle:setPosRot(pos.x, pos.y, pos.z + 0.4, rot.x, rot.y, rot.z, rot.w)
end

local function mpTpToVehicle(server_vehicle_id)
	local c_id = serverVehicleIDToGameVehicleID(server_vehicle_id)-- or getPlayerVehicle(0):getId()
	if not c_id then return end
	
	local c_veh = be:getObjectByID(c_id)
	if not c_veh then return end
	
	local my_veh = getPlayerVehicle(0)
	if my_veh == nil then return end
	local my_id = MPConfig.getPlayerServerID() + 1 -- need to start at 1
	tpToPos(
		createCircle(c_veh),
		my_id,
		my_veh
	)
end

M.tpToMe = function()
	local my_veh = getPlayerVehicle(0)
	if my_veh == nil then return end
	
	local circle = createCircle(my_veh)
	local my_id = my_veh:getId()
	for index, veh in ipairs(getAllVehicles()) do
		if veh:getId() ~= my_id then
			tpToPos(circle, index, veh)
		end
	end
end

--[[
M.onPreRender = function()
	local my_veh = getPlayerVehicle(0)
	if my_veh == nil then return end
	local circle = createCircle(my_veh)
	
	for _, pos in ipairs(circle) do
		debugDrawer:drawSphere(pos, 1, ColorF(1,1,1,1))
	end
end
]]

M.onWorldReadyState = function(state)
	if state == 2 and AddEventHandler then
		AddEventHandler("stp_tpto", mpTpToVehicle)
	end
end

return M
