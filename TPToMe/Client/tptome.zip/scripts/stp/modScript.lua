load("stp")
setExtensionUnloadMode("stp", "manual")