load('StreamersVsChat')
setExtensionUnloadMode('StreamersVsChat', 'manual')