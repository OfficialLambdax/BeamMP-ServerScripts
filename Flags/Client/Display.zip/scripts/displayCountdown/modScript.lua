load("displayCountdown")
setExtensionUnloadMode('displayCountdown', "manual")