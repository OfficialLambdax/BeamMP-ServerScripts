local M = {}

local function displayCountdown(data)
    tempData = split(data,"|")
    msg = tempData[1]
    ttl = tempData[2]
    big = tempData[3]
    guihooks.trigger('ScenarioFlashMessage', {{msg, ttl, 0, big}} )
end

local function onExtensionLoaded()
    local currentMpLayout = jsonReadFile("settings/ui_apps/layouts/default/multiplayer.uilayout.json")
    originalMpLayout = currentMpLayout
    local found
    if currentMpLayout then 
        for k,v in pairs(currentMpLayout.apps) do
            if v.appName == "raceCountdown" then
                found = true
            end
        end
        if not found then
            local raceCountdown = {}
            raceCountdown.appName = "raceCountdown"
            raceCountdown.placement = {}
            raceCountdown.placement.bottom = ""
            raceCountdown.placement.height = "240px"
            raceCountdown.placement.left = 0
            raceCountdown.placement.margin = "auto"
            raceCountdown.placement.position = "absolute"
            raceCountdown.placement.right = 0
            raceCountdown.placement.top = "45px"
            raceCountdown.placement.width = "1070px"
            table.insert(currentMpLayout.apps, raceCountdown)
            jsonWriteFile("settings/ui_apps/layouts/default/multiplayer.uilayout.json",currentMpLayout)
            reloadUI()
        end
    end
    AddEventHandler("displayCountdown", displayCountdown)
end

local function onExtensionUnloaded()
    jsonWriteFile("settings/ui_apps/layouts/default/multiplayer.uilayout.json",originalMpLayout)
    Lua:requestReload()
end

local function split(s, sep)
    local fields = {}
    local sep = sep or " "
    local pattern = string.format("([^%s]+)", sep)
    string.gsub(s, pattern, function(c) fields[#fields + 1] = c end)
    return fields
end

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded
M.displayCountdown = displayCountdown

return M