local M = {}
M.routine1Sec = hptimer()


local function enableCompetitiveMode()
	extensions.core_input_actionFilter.addAction(0, 'racingoptions_competitive', true)
	extensions.core_gamestate.setGameState("scenario", "multiplayer", "scenario")
end

local function disableCompetitiveMode()
	extensions.core_input_actionFilter.addAction(0, 'racingoptions_competitive', false)
	extensions.core_gamestate.setGameState("scenario", "multiplayer", "multiplayer")
end

local function onUpdate(dt)
	if M.routine1Sec:stop() > 1000 then
		if editor.isEditorActive() then editor.setEditorActive(false) end
		
		M.routine1Sec:stopAndReset()
	end
end

local function onWorldReadyState(state)
	if state == 2 then
		if AddEventHandler then -- if beammp is present
			local my_template = core_input_actionFilter.createActionTemplate({"vehicleTeleporting", "vehicleMenues", "physicsControls", "funStuff", "aiControls", "walkingMode", "bigMap"})
			extensions.core_input_actionFilter.setGroup('racingoptions_competitive', my_template)
			core_input_actionFilter.addAction(0, "racingoptions_competitive", false)
			
			extensions.core_input_actionFilter.setGroup("racingoptions_constant", {"toggleConsoleNG","toggleConsole","nodegrabberAction","nodegrabberGrab","nodegrabberRender","editorToggle","objectEditorToggle","editorSafeModeToggle","pause","slower_motion","faster_motion","toggle_slow_motion","toggleTraffic","toggleAITraffic","forceField","funBoom","funBreak","funExtinguish","funFire","funHinges","funTires","funRandomTire"})
			core_input_actionFilter.addAction(0, "racingoptions_constant", true)
			
			AddEventHandler("raceoptions_enablecompetitivemode", enableCompetitiveMode)
			AddEventHandler("raceoptions_disablecompetitivemode", disableCompetitiveMode)
			
		else
			M.onUpdate = nil
		end
	end
end

M.enableCompetitiveMode = enableCompetitiveMode
M.disableCompetitiveMode = disableCompetitiveMode

M.onWorldReadyState = onWorldReadyState
M.onUpdate = onUpdate
return M
