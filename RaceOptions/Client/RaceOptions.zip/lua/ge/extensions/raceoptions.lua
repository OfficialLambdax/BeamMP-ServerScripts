local M = {}
M.routine1Sec = hptimer()

-- ----------------------------------------------------------------------------
-- Common
local function isBeamMPSession()
	if MPCoreNetwork then return MPCoreNetwork.isMPSession() end
	return false
end

local function isOwn(game_vehicle_id)
	if not isBeamMPSession() then return true end
	return MPVehicleGE.isOwn(game_vehicle_id)
end

local function alignToSurfaceZ(pos_vec, max)
	local pos_z = be:getSurfaceHeightBelow(vec3(pos_vec.x, pos_vec.y, pos_vec.z + 2))
	if pos_z < -1e10 then return end -- "the function returns -1e20 when the raycast fails"
	if max and math.abs(pos_vec.z - pos_z) > max then return end
	
	return vec3(pos_vec.x, pos_vec.y, pos_z)
end

local function evalTPPosition(pos_vec, vehicle, factor)
	local new_pos = alignToSurfaceZ(pos_vec, 7)
	if not new_pos then return pos_vec end -- tp pos is in the air
	
	local bounding_box = vehicle:getSpawnWorldOOBB()
	local half_extends = bounding_box:getHalfExtents()
	new_pos = new_pos + vec3(0, 0, half_extends.z / (factor or 4)) -- if this ports the vehicle into the ground when damaged, reduce it to / 3
	
	return new_pos
end

-- ----------------------------------------------------------------------------
-- Custom Events
M.enableCompetitiveMode = function()
	extensions.core_input_actionFilter.addAction(0, 'racingoptions_competitive', true)
end

M.disableCompetitiveMode = function()
	extensions.core_input_actionFilter.addAction(0, 'racingoptions_competitive', false)
end

M.resetAllOwnedVehicles = function()
	for _, vehicle in ipairs(getAllVehicles()) do
		if isOwn(vehicle:getId()) then
			local pos_vec = evalTPPosition(vehicle:getPosition(), vehicle, 4)
			vehicle:setPosRot(pos_vec.x, pos_vec.y, pos_vec.z + 0.1, 0, 0, 0, 0)
		end
	end
end

-- ----------------------------------------------------------------------------
-- Game Events
M.onUpdate = function(dt)
	if M.routine1Sec:stop() > 1000 then
		if editor.isEditorActive() then editor.setEditorActive(false) end
		
		M.routine1Sec:stopAndReset()
	end
end

M.onWorldReadyState = function(state)
	if state == 2 then
		if isBeamMPSession() then
			local my_template = core_input_actionFilter.createActionTemplate({"physicsControls", "funStuff", "aiControls"})
			extensions.core_input_actionFilter.setGroup('racingoptions_competitive', my_template)
			core_input_actionFilter.addAction(0, "racingoptions_competitive", false)
			
			extensions.core_input_actionFilter.setGroup("racingoptions_constant", {"toggleConsoleNG","toggleConsole","nodegrabberAction","nodegrabberGrab","nodegrabberRender","editorToggle","objectEditorToggle","editorSafeModeToggle","pause","slower_motion","faster_motion","toggle_slow_motion","toggleTraffic","toggleAITraffic","forceField","funBoom","funBreak","funExtinguish","funFire","funHinges","funTires","funRandomTire"})
			core_input_actionFilter.addAction(0, "racingoptions_constant", true)
			
			AddEventHandler("raceoptions_enablecompetitivemode", M.enableCompetitiveMode)
			AddEventHandler("raceoptions_disablecompetitivemode", M.disableCompetitiveMode)
			AddEventHandler("raceoptions_resetAllOwnedVehicles", M.resetAllOwnedVehicles)
			
		else
			M.onUpdate = nil
		end
	end
end

return M
